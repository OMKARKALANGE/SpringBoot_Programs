package com.anudip.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.anudip.entity.Courses;

public interface CoursesRepository extends JpaRepository<Courses, Integer>
{

}
