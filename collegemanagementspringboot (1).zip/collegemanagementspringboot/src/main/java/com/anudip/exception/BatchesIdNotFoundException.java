package com.anudip.exception;

public class BatchesIdNotFoundException extends RuntimeException
{
	public BatchesIdNotFoundException(String message)
	{
		super(message);
		
	}
}
