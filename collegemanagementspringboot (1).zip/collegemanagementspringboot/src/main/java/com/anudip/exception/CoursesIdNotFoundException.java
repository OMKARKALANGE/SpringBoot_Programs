package com.anudip.exception;

public class CoursesIdNotFoundException extends RuntimeException
{
	public CoursesIdNotFoundException(String message)
	{
		super(message);
		
	}
}
