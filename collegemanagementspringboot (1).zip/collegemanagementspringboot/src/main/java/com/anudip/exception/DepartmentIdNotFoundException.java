package com.anudip.exception;

public class DepartmentIdNotFoundException extends RuntimeException
{
	public DepartmentIdNotFoundException(String message)
	{
		super(message);
		
	}
}
