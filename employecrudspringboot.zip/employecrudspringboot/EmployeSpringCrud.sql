create database empspringcrud;
use empspringcrud;
show tables;

select * from employee;
select * from department;